import React from 'react';
import CounterSection from './CounterSection';

function Main() {
  return (
    <main style={{ padding: '20px' }}>
      <CounterSection />
    </main>
  );
}

export default Main;
