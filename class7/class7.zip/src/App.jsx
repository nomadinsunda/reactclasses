import { useState, useEffect, useRef } from 'react';
import Header from './components/Header';
import Main from './components/Main';
import Footer from './components/Footer';
import Sidebar from './components/Sidebar';
import Welcome from './components/Welcome';
import './App.css';

function App() {
  const [theme, setTheme] = useState('light');
  const [users, setUsers] = useState([
    { id: 1, name: '홍길동', birth: '1990-01-01', country: 'kr', bio: '프론트엔드 개발자입니다.' },
    { id: 2, name: 'Jane', birth: '1985-03-21', country: 'us', bio: '백엔드 개발자입니다.' },
    { id: 3, name: 'Tom', birth: '1992-08-15', country: 'uk', bio: '풀스택 엔지니어입니다.' }
  ]);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [showWelcome, setShowWelcome] = useState(true);

  const ref = useRef();

  console.log('1. 함수 본문 실행됨 (렌더링 직전)');

  // ✅ 테마 변경 감지
  useEffect(() => {
    console.log(`🎨 테마가 ${theme}로 변경되었습니다.`);
  }, [theme]);

  // ✅ 사용자 목록 변경 → localStorage에 저장
  useEffect(() => {
    localStorage.setItem('users', JSON.stringify(users));
    console.log('✅ 사용자 목록이 localStorage에 저장되었습니다.');
  }, [users]);

  // ✅ 선택된 사용자 변경 감지
  useEffect(() => {
    console.log('3. useEffect 실행됨');
    console.log('4. ref로 접근한 DOM:', ref.current);

    if (selectedUserId !== null) {
      console.log(`👤 선택된 사용자 ID: ${selectedUserId}`);
    } else {
      console.log("아무도 선택되지 않았어요");
    }
  }, [selectedUserId]);

  // ✅ Welcome 메시지를 3초 후 제거
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowWelcome(false);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  // ✅ 창 닫기 전 경고 메시지
  useEffect(() => {
    const handleBeforeUnload = (e) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, []);

  // ✅ 키보드 N 키로 사용자 추가
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key.toLowerCase() === 'n') {
        addUser();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [users]);

  // 🔧 사용자 추가 함수
  const addUser = () => {
    const newUser = {
      id: Date.now(),
      name: 'New User',
      birth: '2000-01-01',
      country: 'kr',
      bio: '자기소개를 작성해주세요.'
    };
    setUsers([...users, newUser]);
  };

  // 🔧 사용자 삭제 함수
  const deleteUser = (id) => {
    setUsers(users.filter(user => user.id !== id));
    if (selectedUserId === id) setSelectedUserId(null);
  };

  // 🔧 사용자 수정 함수
  const updateUser = (updatedUser) => {
    setUsers(users.map(user => user.id === updatedUser.id ? updatedUser : user));
  };

  // 🔧 선택된 사용자 찾기
  const selectedUser = users.find(u => u.id === selectedUserId);

  return (
    <div className={`app ${theme}`}>
      
      {console.log('2. JSX 렌더링')}

      {showWelcome && <Welcome name="hello" />}
      <Header title="회원 관리 시스템" theme={theme} setTheme={setTheme} />
      <div style={{ display: 'flex' }}>
        <Sidebar users={users} onAddUser={addUser} onSelectUser={setSelectedUserId} />
        <Main user={selectedUser} onUpdateUser={updateUser} onDeleteUser={deleteUser} />
      </div>
      <Footer total={users.length} />
    </div>
  );
}

export default App;
