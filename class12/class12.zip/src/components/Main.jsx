import React, { useReducer } from 'react'
import TodoInput from './TodoInput'
import TodoList from './TodoList'
import TodoControls from './TodoControls'

// reducer 함수
function todoReducer(state, action) {
  switch (action.type) {
    case 'ADD':
      return [...state, { id: Date.now(), text: action.text, done: false }]
    case 'REMOVE':
      return state.filter(todo => todo.id !== action.id)
    case 'TOGGLE':
      // todo는 todos의 각 element
      return state.map(todo =>
        todo.id === action.id ? { ...todo, done: !todo.done } : todo
      )
    case 'CLEAR':
      return []
    default:
      return state
  }
}

function Main() {
  // todos은 empty array
  const [todos, dispatch] = useReducer(todoReducer, [])

  /* todos 예
    [
      { id: 1, text: '공부하기', done: false },
      { id: 2, text: '운동하기', done: true }
    ]

  */

  return (
    <main style={{ padding: '20px' }}>
      <TodoInput dispatch={dispatch} />
      <TodoList todos={todos} dispatch={dispatch} />
      <TodoControls dispatch={dispatch} />
    </main>
  )
}

export default Main
