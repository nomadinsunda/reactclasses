function TodoControls({ dispatch }) {
  return (
    <div style={{ marginTop: '20px' }}>
      <button onClick={() => dispatch({ type: 'CLEAR' })}>전체 삭제</button>
    </div>
  )
}

export default TodoControls
