function TodoItem({ todo, dispatch }) {
  const { id, text, done } = todo

  return (
    <li style={{ marginTop: '10px' }}>
      <span
        onClick={() => dispatch({ type: 'TOGGLE', id })}
        style={{
          textDecoration: done ? 'line-through' : 'none',
          cursor: 'pointer',
          marginRight: '10px',
        }}
      >
        {text}
      </span>
      <button onClick={() => dispatch({ type: 'REMOVE', id })}>삭제</button>
    </li>
  )
}

export default TodoItem
