import React, { useState } from 'react';
import Header from './components/Header';
import Main from './components/Main';
import Footer from './components/Footer';
import Welcome from './components/Welcome';

const App = () => {
  const [username, setUsername] = useState('홍길동');
  const [age, setAge] = useState(20);
  const [email, setEmail] = useState('');
  const [count, setCount] = useState(0);
  const [darkMode, setDarkMode] = useState(false);

  const appStyle = {
    backgroundColor: darkMode ? '#222' : '#fff',
    color: darkMode ? '#eee' : '#000',
    minHeight: '100vh',
    fontFamily: 'sans-serif',
    transition: 'all 0.3s ease'
  };

  return (
    <div style={appStyle}>
      <Welcome name="hello" />
      <Header
        title="React State 관리 마스터 예제"
        subtitle="여러 state와 컴포넌트로 확장"
      />
      <Main
        username={username}
        setUsername={setUsername}
        age={age}
        setAge={setAge}
        email={email}
        setEmail={setEmail}
        count={count}
        setCount={setCount}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />
      <Footer author="React 마스터" />
    </div>
  );
};

export default App;
