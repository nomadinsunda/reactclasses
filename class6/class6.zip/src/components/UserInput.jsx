import React from 'react';

const UserInput = ({ username, setUsername, age, setAge }) => {
  return (
    <section>
      <h2>🙋 사용자 정보 입력</h2>
      <input
        type="text"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        placeholder="이름 입력"
        style={{ padding: '8px', marginRight: '10px' }}
      />
      <input
        type="number"
        value={age}
        onChange={(e) => setAge(Number(e.target.value))}
        placeholder="나이 입력"
        style={{ padding: '8px' }}
      />
    </section>
  );
};

export default UserInput;
